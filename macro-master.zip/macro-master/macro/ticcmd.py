# Uses ticcmd to send and receive data from the Tic over USB.
# Works with either Python 2 or Python 3.
#
# NOTE: The Tic's control mode must be "Serial / I2C / USB".

import subprocess
import yaml
import warnings
import time

max_position = 133000

__all__ = ['energize',
           'deenergize',
           'get_position',
           'goto_position'
           ]


def ticcmd(*args):
    return subprocess.check_output(['ticcmd'] + list(args))


def energize():
    ticcmd('--resume')


def status():
    return yaml.load(ticcmd('-s', '--full'))


def deenergize():
    print("Returning to zero...")
    ticcmd('--exit-safe-start', '--position', '0')
    while get_position() != 0:
        time.sleep(1)
    print("De-energizing stepper motor.")
    ticcmd('--deenergize')


def get_position():
    status = yaml.load(ticcmd('-s', '--full'))
    position = status['Current position']
    return position


def goto_position(new_position, limits=None):
    if limits is None:
        limits = [0, 133000]

    new_position = int(round(new_position))
    if (new_position < limits[0]) or (new_position > limits[1]):
        raise ValueError("Requested position {} out of acceptable range [{}, {}]".format(
            new_position, limits[0], limits[1]))

    print("Setting target position to {}.".format(new_position))
    pre_position = get_position()
    ticcmd('--exit-safe-start', '--position', str(new_position))

    # Wait for it to get there, but carefully
    there_yet = False
    strikes = 0
    while not there_yet:
        time.sleep(0.25)
        recheck = get_position()
        if recheck == new_position:
            there_yet = True  # Loop will exit
            return True
        elif pre_position == recheck:
            # Something's wrong, maybe stuck
            strikes += 1
        else:
            # In progress, continue
            strikes = 0
            continue

        # Exit condition
        if strikes > 2:
            warnings.warn('Requested position {} but appears stuck at {}, check system!')
            return False

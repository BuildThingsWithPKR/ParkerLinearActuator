import serial
import warnings
import serial.tools.list_ports
import copy
import time

import numpy as np

from .ticcmd import energize, deenergize, get_position, goto_position


# Original cal was 0.781908306685551, Linear regression slope from data.csv
# relating stepper position to encoder position
default_calibration = 1.0


def sign(x):
    if x < 0:
        return -1
    else:
        return 1


def _find_arduino(baudrate=9600):
    """
    Attempt to find an Arduino automatically in the connected devices
    and connect to it.
    """
    arduino_ports = [
        p.device
        for p in serial.tools.list_ports.comports()
        if 'USB' in p.name  # may need tweaking to match new arduinos
    ]
    if not arduino_ports:
        raise IOError("No Arduino found")
    if len(arduino_ports) > 1:
        warnings.warn('Multiple Arduinos found - using the first at {}'.format(
            arduino_ports[0]))

    ser = serial.Serial(arduino_ports[0], baudrate=baudrate)
    return ser


def chk_encoder():
    ser = _find_arduino()
    ser.write(b'?')  # Ask the Arduino nicely
    encoder = int(ser.readline().strip())
    position = 0.488 * encoder
    return position


def reset_encoder():
    ser = _find_arduino()
    ser.write(b'!')  # Ask the Arduino nicely
    if b'Reset' not in ser.readline().strip():
        warnings.warn('Encoder may not have reset properly.')
    else:
        print('Encoder reset.')
    return chk_encoder()


class Macro(object):
    """
    Set up the macro rail controller

    Parameters
    ----------
    baudrate : int, optional
        Serial connection baud to Arduino.  Defaults to 9600.
    timer : float, optional
        Shot delay after firing.  Defaults to 5 sec (+1 for mirror up and exposure).
    microstepping : int, optional
        Number of subdivided steps per full step set in the stepper controller.
        Defaults to 16.
    calibration : float, optional
        The number of encoder steps per motor microstep.  Default is `None`, which
        will reference the default calibration result from data.csv.
    tol : int, optional
        Acceptable encoder offset relative to expected positioning.  Default of 8 is
        plus or minus half a step, basically +/- 4 um.
    """
    def __init__(self, baudrate=9600, timer=5, microstepping=16, calibration=None,
                 tol=4, limits=[0, int(133000 * 10/16 / 0.488)], pretimer=None):
        self.ser = _find_arduino()
        energize()
        self.encoder = None
        self._encoder_position()
        self._target = 0      # Motor
        self._origin = 0      # Motor
        self.timer = timer
        self.start = None
        self.end = None
        self.microstepping = microstepping
        if calibration is not None:
            self._cal = calibration
        else:
            # Use reference calibration
            self._cal = default_calibration

        self._tol = tol
        self.limits = limits
        self.offset_pos = copy.copy(self.encoder)
        self.offset_neg = copy.copy(self.encoder)
        self.move(2000)  # Move 2 mm
        if pretimer is None:
            self.pretimer = 0
        else:
            self.pretimer = pretimer

    def _chk_serial(self):
        if not self.ser.is_open:
            self.ser = _find_arduino()
        else:
            pass

    def _encoder_position(self):
        """
        Update the encoder position, while also noting prior position.
        """
        self._chk_serial()
        self.ser.write(b'?')  # Ask the Arduino nicely
        self.encoder = int(self.ser.readline().strip())
        self.position = 0.488 * self.encoder

    def _reset_encoder(self):
        self._chk_serial()
        self.ser.write(b'!')
        if b'Reset' not in self.ser.readline().strip():
            warnings.warn('Encoder may not have reset properly.')
        else:
            print('Encoder reset.')
        self._encoder_position()  # Update internal position

    def fire_camera(self):
        time.sleep(self.pretimer)
        self._chk_serial()
        self.ser.write(b'$')
        if b'Fired camera' not in self.ser.readline().strip():
            warnings.warn('Camera may not have fired properly.')
        else:
            pass
            # print('Camera fired! Waiting...')
        time.sleep(self.timer + 1)

    def move(self, new_position):
        """
        Move to a new position, specified in microns.
        """
        # Check here, otherwise the internal state is updated before goto_position throws the error
        if new_position < self.limits[0] or new_position > self.limits[1]:
            raise ValueError("The requested position {} is outside safe range {}!".format(
                new_position, self.limits))

        self._target = new_position
        self._origin = copy.copy(self.position)

        # Use correct offset
        if self._target - self._origin > 0:
            offset = self.offset_pos
        else:
            offset = self.offset_neg

        goto_position((self._target  + offset)* 16/10 * self._cal, limits=self.limits)
        self._encoder_position()

        # Closed loop correction
        correction = self._correct_position(offset)

        # Nudge offset if necessary
        # Account for hysteresis in system by tracking 2 separate offsets
        if (self._target - self._origin) > 0:
            self.offset_pos -= correction
        else:
            self.offset_neg -= correction

    def _correct_position(self, offset):
        """
        Correct the platform position after a move via closed loop control.
        """
        move = self._target - self._origin
        print("Requested move from {:.2f} um to {:.2f} um; difference {:.2f} um.".format(
            self._origin, self._target, move))

        moved = self.position - self._origin
        discrepancy = self.position - self._target
        print("Saw {:.2f} um. Discrepancy {:.2f} um.".format(moved, discrepancy))

        # The primary closed loop
        delta = 0
        total_position_correction = 0
        insanity_check = -100000000
        perturb = 0   # Kick it harder if we're stuck
        while abs(discrepancy) > self._tol:
            print("Discrepancy {:.2f} um outside acceptable tolerance {:.2f} um.".format(
                discrepancy, self._tol))

            delta = discrepancy - insanity_check
            if abs(discrepancy) > 2:
                insanity_check = copy.copy(delta)
                perturb = 0
            else:
                perturb += sign(delta) / 2.
                print("Stuck, perturbing {:.2f} um".format(perturb))

            print("Moving {:.0f} steps to reduce discrepancy {:.2f} um to zero.".format(
                -(discrepancy + perturb) * 16/10 * self._cal, discrepancy))
            corrected = (self._target + offset - total_position_correction - discrepancy + perturb) \
                * 16/10 * self._cal
            goto_position(corrected, limits=self.limits)

            total_position_correction += discrepancy

            # Check new position, update discrepancy
            self._encoder_position()
            discrepancy = self.position - self._target

        if total_position_correction == 0:
            return self.position - self._target
        else:
            return total_position_correction

    def set_start(self, start=None):
        """
        Call this when satisfied with the initial camera rail position,
        or pass the position directly.
        """
        if start is not None:
            self.start = start
        else:
            self.start = copy.copy(self.position)

    def set_end(self, end=None):
        """
        Call this when satisfied with the final camera rail position,
        or pass the position directly.
        """
        if end is not None:
            self.end = end
        else:
            self.end = copy.copy(self.position)

    def set_interval(self, interval):
        """
        Experiment, then set the minimum interval between shots (in steps).
        """
        self.interval = abs(int(interval))

    def stack(self):
        """
        Take a stack of macro images.
        """
        print("Beginning macro image stack")
        total_images = int(np.ceil((self.end-self.start)/self.interval)) + 1
        print("There will be a total of {} images.".format(total_images))
        stepper_intervals = np.arange(total_images, dtype=np.float64)*self.interval + self.start

        for position in stepper_intervals:
            print("Moving to position {}".format(position))
            self.move(position)
            print("Firing camera, waiting for {} seconds...".format(self.timer))
            self.fire_camera()

        print("Done!  Returning to starting position.")
        self.move(self.start)

    def shutdown(self):
        deenergize()

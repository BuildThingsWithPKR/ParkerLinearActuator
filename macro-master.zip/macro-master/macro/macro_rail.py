import serial
import warnings
import serial.tools.list_ports
import copy
import time

import numpy as np

from .ticcmd import energize, deenergize, get_position, goto_position

default_calibration = 0.781908306685551  # Linear regression slope from data.csv


def sign(x):
    if x < 0:
        return -1
    else:
        return 1


def _find_arduino(baudrate=9600):
    """
    Attempt to find an Arduino automatically in the connected devices
    and connect to it.
    """
    arduino_ports = [
        p.device
        for p in serial.tools.list_ports.comports()
        if 'USB' in p.name  # may need tweaking to match new arduinos
    ]
    if not arduino_ports:
        raise IOError("No Arduino found")
    if len(arduino_ports) > 1:
        warnings.warn('Multiple Arduinos found - using the first at {}'.format(
            arduino_ports[0]))

    ser = serial.Serial(arduino_ports[0], baudrate=baudrate)
    return ser

class Macro(object):
    """
    Set up the macro rail controller

    Parameters
    ----------
    baudrate : int, optional
        Serial connection baud to Arduino.  Defaults to 9600.
    timer : float, optional
        Shot delay after firing.  Defaults to 5 sec (+1 for mirror up and exposure).
    microstepping : int, optional
        Number of subdivided steps per full step set in the stepper controller.
        Defaults to 16.
    calibration : float, optional
        The number of encoder steps per motor microstep.  Default is `None`, which
        will reference the default calibration result from data.csv.
    tol : int, optional
        Acceptable encoder offset relative to expected positioning.  Default of 8 is
        plus or minus half a step.
    """
    def __init__(self, baudrate=9600, timer=5, microstepping=16, calibration=None, tol=8,
                 limits=[-500, 135000]):
        self.ser = _find_arduino()
        energize()
        self.position = get_position()
        if self.position != 0:
            self._pos_offset = copy.copy(self.position)
            self.position = 0
        else:
            self._pos_offset = 0

        self.position_mm = 0.0
        self.encoder = 0
        self._encoder_position()
        self._target = 0      # Motor
        self._expected = 0.0  # Encoder
        self._origin = 0      # Motor
        self.timer = timer
        self.start = None
        self.end = None
        self.stepperoffset = 0
        self.microstepping = microstepping
        self.setup = False
        if calibration is not None:
            self._cal = calibration
        else:
            # Use reference calibration
            self._cal = default_calibration

        self._tol = tol
        self.limits = limits
        self.move(2000)  # Near zero, but far enough away no problems

    def _chk_serial(self):
        if not self.ser.is_open:
            self.ser = _find_arduino()
        else:
            pass

    def _encoder_position(self):
        self._chk_serial()
        self._encoder_prior = copy.copy(self.encoder)
        self.ser.write(b'?')  # Ask the Arduino nicely
        self.encoder = int(self.ser.readline().strip())
        self.position_mm = 0.000488 * self.encoder

    def _raw_encoder(self):
        self.ser.write(b'?')
        return int(self.ser.readline().strip())

    def _reset_encoder(self):
        self._chk_serial()
        self.ser.write(b'!')
        if b'Reset' not in self.ser.readline().strip():
            warnings.warn('Encoder may not have reset properly.')
        else:
            print('Encoder reset.')
        self._encoder_position()  # Update internal position

    def fire_camera(self):
        self._chk_serial()
        self.ser.write(b'$')
        if b'Fired camera' not in self.ser.readline().strip():
            warnings.warn('Camera may not have fired properly.')
        else:
            print('Camera fired! Waiting...')
        time.sleep(self.timer + 1)

    def move(self, new_position):
        new_position += self._pos_offset

        # Check here, otherwise the internal state is updated before goto_position throws the error
        if new_position < self.limits[0] or new_position > self.limits[1]:
            raise ValueError("The requested position {} ({} after offset) is outside safe range {}!".format(
                new_position - self._pos_offset, new_position, self.limits))

        self._target = new_position
        self._origin = copy.copy(self.position) + self._pos_offset
        self._expected = self.encoder + int(round((self._target - self._origin) / self._cal))
        goto_position(new_position)
        self._encoder_position()

        # Closed loop correction
        self._correct_position()

    def move_enc(self, new_position):
        """
        Trust the encoder, ignore the raw stepper positioning.
        """
        new_enc = self.encoder + int(round((new_position - self._origin) / self._cal))

    def _correct_position(self):
        """
        Correct the platform position after a move via closed loop control.
        """
        moved = self._target - self._origin
        print("Moved from {} to {}, total {} steps.".format(self._origin, self._target, moved))

        encoder_moved = self.encoder - self._encoder_prior
        expected_moved = int(round((self._target - self._origin) / self._cal))
        print("Expecting {} encoder units. Saw {}, {} to {}.".format(expected_moved, encoder_moved,
                                                                     self._encoder_prior, self.encoder))

        # The primary closed loop
        diff_enc = 0
        total_position_correction = 0
        insanity_check = -100000000
        perturb = 0   # Kick it harder if we're stuck
        perturb2 = 0.0  # Kick it even harder if we're really stuck
        while np.abs(self._expected - self.encoder - diff_enc) > self._tol:
            print("Difference {} outside acceptable tolerance {}.".format(
                self._expected - self.encoder - diff_enc, self._tol))
            raw_enc_orig = self._raw_encoder()
            encoder_diff = self._expected - self.encoder - diff_enc

            correction = int(round(encoder_diff * self._cal))
            diff = abs(correction - insanity_check)
            if diff > 1:
                insanity_check = copy.copy(correction)
                perturb = 0
            else:
                perturb += sign(correction)
                print("Stuck, perturbing {}".format(perturb + perturb2))
                correction += perturb * 2 + int(perturb2)
                perturb2 += perturb / 3

            total_position_correction += correction

            print("Correcting by {} to reduce encoder offset {} to zero.".format(correction, encoder_diff))
            goto_position(self._target + correction)
            diff_enc += self._raw_encoder() - raw_enc_orig

        # Cleanup
        self._pos_offset += total_position_correction
        self.position = get_position() - self._pos_offset
        self._encoder_position()

    def set_start(self, start=None):
        """
        Call this when satisfied with the initial camera rail position,
        or pass the position directly.
        """
        if start is not None:
            self.start = start
        else:
            self.start = copy.copy(self.position)

    def set_end(self, end=None):
        """
        Call this when satisfied with the final camera rail position,
        or pass the position directly.
        """
        if end is not None:
            self.end = end
        else:
            self.end = copy.copy(self.position)

    def set_interval(self, interval):
        """
        Experiment, then set the minimum interval between shots (in steps).
        """
        self.interval = abs(int(interval))

    def stack(self):
        """
        Take a stack of macro images.
        """
        print("Beginning macro image stack")
        total_images = int(np.ceil((self.end-self.start)/self.interval)) + 1
        print("There will be a total of {} images.".format(total_images))
        stepper_intervals = np.arange(total_images, dtype=np.int32)*self.interval + self.start

        for position in stepper_intervals:
            print("Moving to position {}".format(position))
            self.move(position)
            print("Firing camera, waiting for {} seconds...".format(self.timer))
            self.fire_camera()

        print("Done!  Returning to starting position.")
        self.move(self.start)

    def shutdown(self):
        deenergize()

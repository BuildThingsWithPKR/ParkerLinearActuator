__all__ = ['Macro',
           ]

from .macro_rail_encoder import Macro
from .macro_rail import Macro as MacroOld

# Introduction

This repo contains info and code for a DIY macro rail, based on the Parker 803-9288E.

Currently the project uses

* Raspberry Pi 
	* High level system control in Python
	* Communicate with Tic controller using `ticcmd` command-line interface via Python
	* Feedback from encoder info passed via PySerial from Arduino (Uno or compatible for definite Nikon IR remote shutter control)
	* VNC remote desktop control from any nearby device
* Arduino for monitoring a high resolution stepper encoder, with asymmetric communcation via USB Serial (currently a MicroView for OLED troubleshooting, may transition to a Nano Every)
* Pololu Tic stepper controller (T249) to drive stepper and basic homing with limit sensor

# Organization

* `actuators`:  Info about the linear actuators available
* `arduino`:  Arduino sketches
* `macro`:  The pure-Python package
* `datasheets`:  PDF documentation where available/relevant for posterity
